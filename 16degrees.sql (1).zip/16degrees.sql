-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 2015-12-10 16:53:04
-- 服务器版本： 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `16degrees`
--

-- --------------------------------------------------------

--
-- 表的结构 `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` char(1) COLLATE utf8_unicode_ci DEFAULT '1',
  `src1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `src2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `src3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `src4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_cn` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name_en` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price` float DEFAULT NULL,
  `desc` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `years` int(4) DEFAULT NULL,
  `field` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sort` int(10) DEFAULT NULL,
  `brand` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `chateau` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `modify_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name_cn` (`name_cn`,`name_en`,`price`,`desc`,`years`,`field`,`sort`,`chateau`),
  KEY `brand` (`brand`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=41 ;

--
-- 转存表中的数据 `product`
--

INSERT INTO `product` (`id`, `type`, `src1`, `src2`, `src3`, `src4`, `name_cn`, `name_en`, `price`, `desc`, `years`, `field`, `sort`, `brand`, `chateau`, `active`, `modify_time`) VALUES
(5, '1', NULL, NULL, NULL, NULL, 'fwef', 'wefwef', 0, '<p>fwefwefwefwef</p>\r\n', 0, NULL, NULL, NULL, NULL, '1', 1439570349),
(6, '1', NULL, NULL, NULL, NULL, 'fwefw', 'efwefwef', 18, '<p>ffffffffffff</p>\r\n', 26, NULL, NULL, NULL, NULL, '1', 1439902717),
(7, '1', NULL, NULL, NULL, NULL, 'fwefw', 'efwefwef', 18, '<p>ffffffffffff</p>\r\n', 26, NULL, NULL, NULL, NULL, '1', 1439902721),
(8, '2', NULL, NULL, NULL, NULL, 'fwefwef', 'wefwefwef', 121, '<p>rrrrrrrrrrrrrrrrrrrrrrrgerger</p>\r\n', 200, NULL, NULL, NULL, NULL, '1', 1439902926),
(9, '2', NULL, NULL, NULL, NULL, 'fwefwef', 'wefwefwef', 121, '<p>rrrrrrrrrrrrrrrrrrrrrrrgerger</p>\r\n', 200, NULL, NULL, NULL, NULL, '1', 1439902936),
(16, '1', NULL, NULL, NULL, NULL, 'gergerg', 'ergerg', 233, '', 123, NULL, NULL, NULL, NULL, '1', 1439909229),
(21, '1', NULL, NULL, NULL, NULL, 'gerge', 'rgerg', 0, '<hr />\r\n<p>gergergerg</p>\r\n', 0, NULL, NULL, NULL, NULL, '1', 1439912716),
(22, '1', NULL, NULL, NULL, NULL, 'fwefw', 'efwefwef', 0, '', 0, NULL, NULL, NULL, NULL, '1', 1439912799),
(23, '1', NULL, NULL, NULL, NULL, 'fwefw', 'efwefwef', 12, '<p>fwefwefw</p>\r\n', 12312313, NULL, NULL, NULL, NULL, '1', 1439912946),
(24, '1', NULL, NULL, NULL, NULL, 'tgt', '34t34t3', 34, '', 34, NULL, NULL, NULL, NULL, '1', 1439913031),
(26, '1', NULL, NULL, NULL, NULL, 'fffffffffffwefwefwef', '123123123', 123456, '<p>fwefwefw</p>\r\n', 12312, NULL, NULL, NULL, NULL, '1', 1439913686),
(27, '4', NULL, NULL, NULL, NULL, 'fwefwe', 'fwefwef', 12312, '<p>fwefwfewefwef</p>\r\n', 123123, NULL, NULL, NULL, NULL, '1', 1439913889),
(28, '4', NULL, NULL, NULL, NULL, 'fwefwe', 'fwefwef', 12312, '\r\nfwefwfewefwef\r\n\r\n\r\n', 123123, NULL, NULL, NULL, NULL, '1', 1439913889),
(29, '4', NULL, NULL, NULL, NULL, 'fwefwe', 'fwefwef', 12312, '\r\nfwefwfewefwef\r\n\r\n\r\n', 123123, NULL, NULL, NULL, NULL, '1', 1439913889),
(30, '', NULL, NULL, NULL, NULL, '', '', 0, '', 0, NULL, NULL, NULL, NULL, '1', 1439992596),
(31, '2', NULL, NULL, NULL, NULL, 'ffffffff', 'fffffffffffffffffffffffffffffffffffffff', 123123, '<p>wefwefwfewefwef</p>\r\n', 12312313, NULL, NULL, NULL, NULL, '1', 1439992921),
(32, '2', NULL, NULL, NULL, NULL, 'gergerg', 'ergerge', 123, '<p>fwefwefwefwef</p>\r\n', 1212, NULL, NULL, NULL, NULL, '1', 1439994912),
(33, '1', '33_1.png', '33_2.png', '33_3.png', '33_4.png', 'wefwef', 'wefwefwef', 1212, '<p>ergergegegergergerg</p>\r\n', 1212, NULL, NULL, NULL, NULL, '1', 1439995090),
(34, '1', '34_1.png', '34_2.png', NULL, NULL, 'erger', 'gergerg', 1231, '<p>efwefwefwefwef</p>\r\n', 1212, NULL, NULL, NULL, NULL, '1', 1439996177),
(35, '1', '35_1.png', '35_2.png', '35_3.png', NULL, 'fwef', 'wefwef', 123, '<p>fwefwefwefwef</p>\r\n', 1212, NULL, NULL, NULL, NULL, '1', 1439996271),
(36, '', '36_1.png', NULL, NULL, NULL, 'fwefw', 'efwefwe', 1212, '<p>fwefwefwef</p>\r\n', 12121, NULL, NULL, NULL, NULL, '1', 1439996493),
(37, '1', '37_1.png', '37_2.png', '37_3.png', '37_4.png', 'fwef', 'wefwef', 12, '<p>dgrgrgergerge</p>\r\n', 1212, NULL, NULL, NULL, NULL, '1', 1440001520),
(38, '1', '38_1.png', '38_2.png', NULL, NULL, 'fwef', 'wefwefwef', 12, '<p>fwefwef</p>\r\n', 1212, NULL, NULL, NULL, NULL, '3', 1440001742),
(39, '1', '39_1.png', NULL, NULL, NULL, 'fwe', 'fwefwef', 12, '<p>dfbdfbdfbdfb</p>\r\n', 1212, NULL, NULL, NULL, NULL, '1', 1440001850),
(40, '1', '40_1.png', NULL, NULL, NULL, 'fwefwe', 'fwefwef', 12, '<p>fwefwefwef</p>\r\n', 12, NULL, NULL, NULL, NULL, '3', 1440002022);

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `salt` varchar(255) NOT NULL,
  `display_name` varchar(45) NOT NULL,
  `group` smallint(5) unsigned NOT NULL,
  `create_time` int(10) unsigned NOT NULL,
  `last_login_hash` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `group` (`group`),
  KEY `last_login_hash` (`last_login_hash`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `salt`, `display_name`, `group`, `create_time`, `last_login_hash`) VALUES
(2, 'admin', '16degrees', '', '管理员', 1, 0, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `wine_type`
--

CREATE TABLE IF NOT EXISTS `wine_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
